
### Retransmision de cámara
Si bien el objetivo final es la retransmisión en vivo del rebaño de ovejas de un predio, nos supone una limitante práctica de no contar con una cámara ip instalada en un predio la cual podamos usar para presentar el proyecto en óptimas condiciones por lo que considerando el proyecto como un prototipo, se opta por simular dicha transmisión de la manera más fidedigna posible.
Para ello se usará un video previamente grabado sobre un rebaño de ovejas en el cual se destacan situaciones de interés(contabilizacion de ovejas,dispersion,agentes externos,etc). Para llevar a cabo la simulación se decide levantar un** servicio en docker con FFMPEG **el cual en su conjunto nos permitirá representar una cámara IP, la cual nos servirá como fuente de video, adicionalmente se levantará otro **servicio docker con MediaXMT **, el cual nos servira de servidor de streaming del rebaño en "directo" el cual recibira desde el servicio anterior el flujo de video via protocolo RTSP (mismo usado en cámaras IP real)  y luego retransmitirá a través del puerto 888 via protocolo HLS en el navegador web, el cual el cliente podrá consultar.

### Servicios y protocolos
RTSP (Real Time Streaming Protocol o Protocolo de Transmisión en Tiempo Real) es un **protocolo de red diseñado para controlar la entrega de datos multimedia en tiempo real, XMT hace uso de este protocolo para permitirnos publicar y leer retransmisiones.**
* Necesitaremos de un cliente capaz de leer RTSP, es decir como un reproductor de video como VLC, en este caso usaremos **FFMPEG (el cual actuará mockeando una cámara IP)**
* Posteriormente las republicaremos para ser vistas desde el navegador en tiempor real vía protocolo HLS.
```
                ┌──────────────────────────┐
                │       CÁMARA IP          │
                │   RTSP / ONVIF / HTTP    │
                └────────────┬─────────────┘
                             │
                             ▼
                ┌──────────────────────────┐
                │      RASPBERRY PI         │
                │                          │
                │  Captura de video        │
                │       ↓                  │
                │  YOLO / OpenCV           │
                │       ↓                  │
                │  Conteo de animales      │
                │  Detección de eventos    │
                │       ↓                  │
                │  Envío de datos           │
                └────────────┬─────────────┘
                             │
                     Internet / 4G / WiFi
                             │
                             ▼
          ┌─────────────────────────────────────┐
          │              BACKEND                 │
          │                                     │
          │  API REST / WebSocket               │
          │  Autenticación                      │
          │  Gestión del rebaño                 │
          │  Gestión de dispositivos            │
          │  Eventos / alertas                  │
          │  Usuarios                           │
          └───────────────┬─────────────────────┘
                          │
           ┌──────────────┴──────────────┐
           ▼                             ▼
   ┌─────────────────┐          ┌─────────────────┐
   │   BASE DATOS    │          │ NOTIFICACIONES  │
   │                 │          │                 │
   │ PostgreSQL      │          │ Push / Email    │
   │ animales        │          │ etc.            │
   │ eventos         │          └────────┬────────┘
   │ cámaras         │                   │
   │ usuarios        │                   │
   └─────────────────┘                   │
                                         ▼
                              ┌───────────────────┐
                              │    APP MÓVIL      │
                              │                   │
                              │ Rebaño            │
                              │ Animales           │
                              │ Alertas            │
                              │ Estadísticas       │
                              │ Cámaras            │
                              │ Configuración      │
                              └───────────────────┘
```



---


MediaMTX es el servidor de streaming 
	* Recibe video RTSP
	* Expone el flujo para la visualización (HLS,WebRTC,etc)
	* Sirve como centro de distribución de video
	* Permite ver el stream en navegador y conectarlo con otros servicios

Cámara mock es la fuenta simulada de video (cámara virtual del sistema)
	* No es un servidor
	* Es una app que emite una secuencia de video local en loop
	* Se usa FFmpeg para reproducir un archivo
	* Manda dicho video a MediaMTX por RTSP
![](https://beta.appflowy.cloud/api/file_storage/ade6b4e7-7906-46bd-a019-84e2c4d40370/v1/blob/d1c7c247-a4ab-4bf8-a541-94f17422dc21/55M8rIK65gBwdu429Z2d94N2TkHGqYje49EKPu83UXw=.png)
* MediaMTX estará escuchando por el puerto 8554 para RTSP
* La reproducción se podrá ver por el puerto 8889 por la UI via WebRTC
* El flujo de prueba se llama rebano
![](https://beta.appflowy.cloud/api/file_storage/ade6b4e7-7906-46bd-a019-84e2c4d40370/v1/blob/d1c7c247-a4ab-4bf8-a541-94f17422dc21/9nX2q8eLR1E9ZzkUwUsvbbrKTy51N-r1mpUXDt8l1-8=.png)
“Para la demo y validación del sistema, se utiliza una fuente de video simulada en RTSP a partir de un archivo de video reproducido en loop, replicando el comportamiento de una cámara IP real. La arquitectura y los protocolos de producción son los mismos que se usarían con una cámara física"
Para verlo en el navegador se usará protocolo WebRTC que ofrece baja latencia, compatible con mediaMTX ya que éste expone puerto para dicho servicio (8889)

	WebRTC realiza conexion peer to peer (punto a punto) . WebRTC transmite el video a través del puerto UDP 8189 (protocolo ICE) 
	WebRTC divide su trabajo en dos fases completamente separadas:
	1. Señalización (puerto TCP8889) → entrega pagina web para ver en navegador y negocia conexión entre MediaMTX y el navegador
	1. Transporte del video (puerto UDP 8189) → una vez de acuerdo la conexion anterior comienza la transmisión de video por lo que se usa el protocolo UDP en puerto 8189


### Retransmisión a servidor ia+python
* Separar flujo de visualizacion → alta tasa de cuadros (30-60FPS) para el cliente (vista web) y pocos cuadros(5-10FPS) hacia el servidor de ia para ahorrar hardware ya que desde ahi post-procesamiento se enviarán alertas sobre cantidad de animales,detecciones inusuales,perimetro y no un flujo constante de video en vivo ya que parece se consulta al enlace web adicional.
* Definir  **paths **independientes** **en MediaMTX. Uno para cliente web via HLS y otro a al server de  python via protocolo RTSP. Dentro habrá un script que descartara cuadros antes de ser procesados en el servidor IA.
* Configurar FFmpeg para que envíe el video original a 30/60 FPS.

